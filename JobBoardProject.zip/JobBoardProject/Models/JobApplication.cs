﻿using System;
using System.ComponentModel.DataAnnotations;

namespace JobBoardWebApp.Models
{
    public class JobApplication
    {
        public int Id { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string ResumeFilePath { get; set; }

        [Required]
        public string CoverLetter { get; set; }

        public string JobTitle { get; set; }

        public DateTime ApplicationDate { get; set; } = DateTime.Now;

        // 🔽 Add these two lines:
        public int? UserId { get; set; }
        public User User { get; set; }
    }
}
