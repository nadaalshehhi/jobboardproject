﻿using Microsoft.AspNetCore.Mvc;
using JobBoardWebApp.Models;
using JobBoardWebApp.Data;

namespace JobBoardWebApp.Controllers
{
    public class SignupController : Controller
    {
        private readonly AppDbContext _context;

        public SignupController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                ViewBag.Message = "Signup successful!";
            }

            return View();
        }
    }
}
