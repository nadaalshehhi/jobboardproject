﻿using Microsoft.AspNetCore.Mvc;
using JobBoardWebApp.Data;
using JobBoardWebApp.Models;
using System.Linq;

namespace JobBoardWebApp.Controllers
{
    public class LoginController : Controller
    {
        private readonly AppDbContext _context;

        public LoginController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(User user)
        {
            var existingUser = _context.Users
                .FirstOrDefault(u => u.Email == user.Email && u.Password == user.Password);

            if (existingUser != null)
            {
                // Login successful
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // Login failed
                ViewBag.Message = "Invalid email or password.";
                return View();
            }
        }
    }
}

