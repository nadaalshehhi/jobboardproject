﻿using Microsoft.AspNetCore.Mvc;
using JobBoardWebApp.Data;
using JobBoardWebApp.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace JobBoardWebApp.Controllers
{
    public class ApplicationController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ApplicationController(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [HttpGet]
        public IActionResult Index(string jobTitle)
        {
            var model = new JobApplication
            {
                JobTitle = jobTitle
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(JobApplication model, IFormFile ResumeFile)
        {
            if (ModelState.IsValid)
            {
                if (ResumeFile != null && ResumeFile.Length > 0)
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "resumes");
                    Directory.CreateDirectory(uploadsFolder); // Make sure folder exists
                    var fileName = Path.GetFileName(ResumeFile.FileName);
                    var filePath = Path.Combine(uploadsFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        ResumeFile.CopyTo(stream);
                    }

                    model.ResumeFilePath = "/resumes/" + fileName;
                }

                _context.JobApplications.Add(model);
                _context.SaveChanges();

                ViewBag.Message = "Application submitted successfully!";
                return View(new JobApplication());
            }

            return View(model);
        }
    }
}
