﻿using Microsoft.AspNetCore.Mvc;

namespace JobBoardWebApp.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

