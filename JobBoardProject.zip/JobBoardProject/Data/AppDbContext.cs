﻿using Microsoft.EntityFrameworkCore;
using JobBoardWebApp.Models;
using System.Collections.Generic;

namespace JobBoardWebApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }
        public DbSet<JobApplication> JobApplications { get; set; }

        public DbSet<User> Users { get; set; }
    }
}
